import json

def lambda_handler(event, context):
    """
    Función principal de Lambda que recibe eventos y contexto.
    Devuelve una respuesta simple en formato JSON.
    """
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "¡Hola desde AWS Lambda!",
            "input": event
        })
    }
